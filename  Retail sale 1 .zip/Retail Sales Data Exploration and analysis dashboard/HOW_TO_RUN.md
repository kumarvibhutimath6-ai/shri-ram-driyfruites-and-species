# 🚀 How to Run the Retail Sales Data Exploration & Analysis Dashboard

A complete step-by-step guide to installing dependencies, running data pipelines, and launching the interactive web dashboard.

---

## 📋 Table of Contents
1. [Prerequisites](#1-prerequisites)
2. [Environment Setup & Installation](#2-environment-setup--installation)
3. [Running the Project](#3-running-the-project)
   - [Option A: One-Click Master Pipeline (Recommended)](#option-a-one-click-master-pipeline-recommended)
   - [Option B: Launch the Interactive Web Dashboard](#option-b-launch-the-interactive-web-dashboard)
   - [Option C: Run Step-by-Step Modular Scripts](#option-c-run-step-by-step-modular-scripts)
   - [Option D: Open the Jupyter EDA Notebook](#option-d-open-the-jupyter-eda-notebook)
4. [Using Your Own Custom Dataset](#4-using-your-own-custom-dataset)
5. [Troubleshooting & FAQs](#5-troubleshooting--faqs)

---

## 1. Prerequisites

Make sure you have the following installed on your machine:
* **Python 3.10 or higher** (Check version with: `python --version`)
* **Git** (Optional, for version control)
* **Web Browser** (Chrome, Firefox, Edge, Safari) for viewing the dashboard

---

## 2. Environment Setup & Installation

### Step 2.1: Open Terminal / PowerShell
Open your terminal and navigate to the project root directory:

```bash
cd "c:\Users\ADMIN\OneDrive\Documents\Retail Sales Data Exploration and analysis dashboard"
```

---

### Step 2.2: Create and Activate a Virtual Environment

#### 🔹 On Windows (PowerShell):
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```
> **Note for Windows**: If you get a `Script Execution Policy` error, run:
> ```powershell
> Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
> .venv\Scripts\Activate.ps1
> ```

#### 🔹 On Windows (Command Prompt `cmd`):
```cmd
python -m venv .venv
.venv\Scripts\activate.bat
```

#### 🔹 On macOS / Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

---

### Step 2.3: Install Required Dependencies
Run the following command to install all required libraries:

```bash
pip install -r requirements.txt
```

---

## 3. Running the Project

### Option A: One-Click Master Pipeline (Recommended)
Runs data generation, health audits, data cleaning, feature engineering, and executive KPI calculation in one command:

```bash
python main.py
```

---

### Option B: Launch the Interactive Web Dashboard
To open the live interactive Streamlit analytics dashboard in your browser:

```bash
streamlit run src/dashboard.py
```

*Or via the master CLI:*
```bash
python main.py --dashboard
```

Once started, the dashboard will automatically open in your default browser at:
👉 **`http://localhost:8501`**

---

### Option C: Run Step-by-Step Modular Scripts

If you want to execute each pipeline layer independently:

#### 1️⃣ Step 1: Data Ingestion & Quality Audit
Validates or generates the raw 2,000-transaction retail dataset:
```bash
python src/run_step1.py
```

#### 2️⃣ Step 2: Data Cleaning & Feature Engineering
Transforms raw data, generates temporal/financial features, and outputs `data/processed/cleaned_retail_sales.csv`:
```bash
python src/data_processing.py
```

#### 3️⃣ Re-generate Custom Dataset Size
If you want to create a new raw dataset with a custom number of rows (e.g. 5,000 rows):
```bash
python -c "from src.generate_sample_data import generate_dataset; generate_dataset(num_records=5000)"
```

---

### Option D: Open the Jupyter EDA Notebook

For exploratory analysis, statistical plots, and data science research:

```bash
jupyter notebook notebooks/01_retail_sales_eda.ipynb
```

---

## 4. Using Your Own Custom Dataset

To analyze your own company's sales data instead of the sample data:

1. Copy your CSV file into the [`data/raw/`](file:///c:/Users/ADMIN/OneDrive/Documents/Retail%20Sales%20Data%20Exploration%20and%20analysis%20dashboard/data/raw) folder.
2. Name it `retail_sales_dataset.csv` (or specify your file name in [`src/data_loader.py`](file:///c:/Users/ADMIN/OneDrive/Documents/Retail%20Sales%20Data%20Exploration%20and%20analysis%20dashboard/src/data_loader.py)).
3. Ensure your dataset includes common retail fields (`Date`, `Product_Category`, `Price_per_Unit`, `Quantity`, `Total_Amount`).
4. Re-run the pipeline:
   ```bash
   python main.py
   streamlit run src/dashboard.py
   ```

---

## 5. Troubleshooting & FAQs

### ❓ Issue: `streamlit: command not found`
* **Solution**: Ensure your virtual environment is activated (`.venv\Scripts\Activate.ps1`) before running the command, or run `python -m streamlit run src/dashboard.py`.

### ❓ Issue: Port 8501 is already in use
* **Solution**: Run Streamlit on a different port:
  ```bash
  streamlit run src/dashboard.py --server.port 8502
  ```

### ❓ Issue: Missing file in `data/processed/`
* **Solution**: Run `python src/data_processing.py` to regenerate the processed dataset.

---

## 📞 Summary of Core Commands

| Goal | Command |
| :--- | :--- |
| **Run Full Pipeline** | `python main.py` |
| **Launch Dashboard** | `streamlit run src/dashboard.py` |
| **Run Quality Audit (Step 1)** | `python src/run_step1.py` |
| **Run Data Cleaning (Step 2)** | `python src/data_processing.py` |
| **Open Jupyter Notebook** | `jupyter notebook notebooks/01_retail_sales_eda.ipynb` |
