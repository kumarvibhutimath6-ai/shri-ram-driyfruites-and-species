"""
Data Loader & Validation Module
Handles reading raw and processed datasets, schema verification, and summary diagnostics.
"""

from pathlib import Path
from typing import Dict, Any, List, Optional
import pandas as pd


EXPECTED_RAW_COLUMNS = [
    "Transaction_ID",
    "Date",
    "Customer_ID",
    "Gender",
    "Age",
    "Product_Category",
    "Product_Name",
    "Quantity",
    "Price_per_Unit",
    "Total_Amount",
    "Payment_Method",
    "Region"
]


def get_project_root() -> Path:
    """Returns the absolute root directory of the project."""
    return Path(__file__).resolve().parent.parent


def get_raw_data_dir() -> Path:
    """Returns the path to data/raw/."""
    return get_project_root() / "data" / "raw"


def get_processed_data_dir() -> Path:
    """Returns the path to data/processed/."""
    return get_project_root() / "data" / "processed"


def list_available_raw_files() -> List[str]:
    """Returns list of CSV/Excel/Parquet files present in data/raw/."""
    raw_dir = get_raw_data_dir()
    if not raw_dir.exists():
        return []
    valid_exts = {".csv", ".xlsx", ".xls", ".parquet"}
    return [f.name for f in raw_dir.iterdir() if f.is_file() and f.suffix in valid_exts]


def load_raw_data(filename: str = "retail_sales_dataset.csv") -> pd.DataFrame:
    """
    Loads raw sales dataset from data/raw/ and validates its existence.
    """
    file_path = get_raw_data_dir() / filename

    if not file_path.exists():
        raise FileNotFoundError(
            f"Raw dataset '{filename}' not found at: {file_path}. "
            f"Please run 'python src/generate_sample_data.py' or place your CSV in data/raw/."
        )

    if filename.endswith(".csv"):
        df = pd.read_csv(file_path)
    elif filename.endswith((".xlsx", ".xls")):
        df = pd.read_excel(file_path)
    elif filename.endswith(".parquet"):
        df = pd.read_parquet(file_path)
    else:
        raise ValueError(f"Unsupported file format for: {filename}")

    return df


def load_processed_data(filename: str = "cleaned_retail_sales.csv") -> pd.DataFrame:
    """
    Loads processed dataset from data/processed/.
    """
    file_path = get_processed_data_dir() / filename

    if not file_path.exists():
        raise FileNotFoundError(f"Processed dataset '{filename}' not found at: {file_path}")

    if filename.endswith(".csv"):
        return pd.read_csv(file_path)
    elif filename.endswith((".xlsx", ".xls")):
        return pd.read_excel(file_path)
    elif filename.endswith(".parquet"):
        return pd.read_parquet(file_path)
    else:
        raise ValueError(f"Unsupported file format for: {filename}")


def inspect_dataset_health(df: pd.DataFrame) -> Dict[str, Any]:
    """
    Performs quick health and schema diagnostic on a retail dataset.
    """
    missing_summary = df.isnull().sum().to_dict()
    duplicates_count = int(df.duplicated().sum())
    
    return {
        "total_rows": len(df),
        "total_columns": len(df.columns),
        "columns": list(df.columns),
        "missing_values": missing_summary,
        "duplicate_rows": duplicates_count,
        "dtypes": {col: str(dtype) for col, dtype in df.dtypes.items()}
    }


if __name__ == "__main__":
    try:
        df = load_raw_data("retail_sales_dataset.csv")
        health = inspect_dataset_health(df)
        print("=== DATASET HEALTH & SCHEMA DIAGNOSTIC ===")
        print(f"Total Rows: {health['total_rows']}")
        print(f"Total Columns: {health['total_columns']}")
        print(f"Duplicate Rows: {health['duplicate_rows']}")
        print(f"Columns: {health['columns']}")
    except Exception as e:
        print(f"Error loading dataset: {e}")
