"""
Step 1: Data Ingestion & Schema Diagnostics Pipeline
Executes data acquisition, schema verification, and quality audit.
"""

import sys
import os
from pathlib import Path

# Add project root to sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.append(str(ROOT_DIR))

# Ensure UTF-8 output encoding for Windows terminals
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

from src.generate_sample_data import generate_dataset
from src.data_loader import load_raw_data, inspect_dataset_health, get_raw_data_dir


def execute_step1():
    print("=" * 60)
    print("EXECUTING STEP 1: DATA INGESTION & QUALITY AUDIT")
    print("=" * 60)

    raw_file = get_raw_data_dir() / "retail_sales_dataset.csv"

    # Step 1.1: Ensure raw dataset exists
    if not raw_file.exists():
        print("Raw dataset not found. Generating 2,000 transactions...")
        generate_dataset(num_records=2000)
    else:
        print(f"[OK] Found raw dataset at: {raw_file.name}")

    # Step 1.2: Ingest & load dataset
    print("\nLoading raw dataset via data_loader...")
    df = load_raw_data("retail_sales_dataset.csv")

    # Step 1.3: Quality and health diagnostics
    health = inspect_dataset_health(df)
    print("\n--- DATASET HEALTH & QUALITY REPORT ---")
    print(f"* Total Rows Recorded : {health['total_rows']:,}")
    print(f"* Total Columns       : {health['total_columns']}")
    print(f"* Duplicate Rows      : {health['duplicate_rows']}")
    
    missing_items = {k: v for k, v in health['missing_values'].items() if v > 0}
    if missing_items:
        print(f"* Missing Values      : {missing_items}")
    else:
        print(f"* Missing Values      : 0 (100% complete dataset)")

    # Step 1.4: Schema inspection
    print("\n--- SCHEMA & COLUMN TYPES ---")
    for col in df.columns:
        print(f"  - {col:<20} | Type: {str(df[col].dtype):<10} | Sample: {str(df[col].iloc[0])}")

    # Step 1.5: Numeric summary statistics
    print("\n--- NUMERICAL SUMMARY METRICS ---")
    numeric_cols = ["Age", "Quantity", "Price_per_Unit", "Discount_Percent", "Total_Amount", "Customer_Rating"]
    valid_numeric = [c for c in numeric_cols if c in df.columns]
    print(df[valid_numeric].describe().round(2).to_string())

    # Step 1.6: Categorical distributions
    print("\n--- CATEGORY BREAKDOWN ---")
    cat_counts = df["Product_Category"].value_counts()
    for cat, count in cat_counts.items():
        print(f"  * {cat:<25}: {count} orders ({count/len(df)*100:.1f}%)")

    print("\n" + "=" * 60)
    print("STEP 1 COMPLETE: Raw data is validated and ready for Step 2!")
    print("=" * 60)


if __name__ == "__main__":
    execute_step1()
