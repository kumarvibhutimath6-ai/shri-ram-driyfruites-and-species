"""
Data Processing & Feature Engineering Module
Cleans raw sales records, extracts temporal dimensions, creates demographic cohorts,
calculates financial metrics (Gross Sales, Discounts, Estimated Margins), and saves to data/processed/.
"""

import sys
from pathlib import Path
import numpy as np
import pandas as pd

# Add project root to sys.path
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.append(str(ROOT_DIR))

from src.data_loader import load_raw_data, get_processed_data_dir, get_raw_data_dir


# Estimated Cost-of-Goods-Sold (COGS) ratio by category for retail margin estimation
CATEGORY_COGS_RATIO = {
    "Electronics": 0.65,          # 35% margin
    "Clothing": 0.45,             # 55% margin
    "Beauty & Personal Care": 0.35, # 65% margin
    "Home & Kitchen": 0.55,       # 45% margin
    "Books & Stationery": 0.40    # 60% margin
}


def create_age_groups(series: pd.Series) -> pd.Series:
    """Bins numeric age into demographic segments."""
    bins = [0, 25, 35, 50, 65, 120]
    labels = ["18-25", "26-35", "36-50", "51-65", "65+"]
    return pd.cut(series, bins=bins, labels=labels, right=True)


def process_sales_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Full data cleaning and feature engineering pipeline for retail sales data.
    """
    data = df.copy()

    # 1. Standardize column names (snake_case)
    data.columns = [col.strip().lower().replace(" ", "_").replace("-", "_") for col in data.columns]

    # 2. Date parsing & temporal feature extraction
    if "date" in data.columns:
        data["date"] = pd.to_datetime(data["date"], errors="coerce")
        data["year"] = data["date"].dt.year
        data["month"] = data["date"].dt.month
        data["month_name"] = data["date"].dt.strftime("%b")
        data["year_month"] = data["date"].dt.strftime("%Y-%m")
        data["quarter"] = "Q" + data["date"].dt.quarter.astype(str)
        data["year_quarter"] = data["year"].astype(str) + " " + data["quarter"]
        data["day"] = data["date"].dt.day
        data["day_name"] = data["date"].dt.day_name()
        data["day_of_week"] = data["date"].dt.dayofweek
        data["is_weekend"] = data["day_of_week"].apply(lambda x: 1 if x >= 5 else 0)

    # 3. Numeric & Financial Calculations
    if "price_per_unit" in data.columns and "quantity" in data.columns:
        data["price_per_unit"] = pd.to_numeric(data["price_per_unit"], errors="coerce").round(2)
        data["quantity"] = pd.to_numeric(data["quantity"], errors="coerce").astype(int)
        data["gross_amount"] = (data["price_per_unit"] * data["quantity"]).round(2)

    if "discount_percent" in data.columns:
        data["discount_percent"] = pd.to_numeric(data["discount_percent"], errors="coerce").fillna(0)
        data["discount_amount"] = (data["gross_amount"] * (data["discount_percent"] / 100.0)).round(2)
    else:
        data["discount_percent"] = 0
        data["discount_amount"] = 0.0

    if "total_amount" in data.columns:
        data["total_amount"] = pd.to_numeric(data["total_amount"], errors="coerce").round(2)
    else:
        data["total_amount"] = (data["gross_amount"] - data["discount_amount"]).round(2)

    # 4. Profit & Cost Estimation
    if "product_category" in data.columns:
        data["cogs_ratio"] = data["product_category"].map(CATEGORY_COGS_RATIO).fillna(0.50)
        data["estimated_cost"] = (data["gross_amount"] * data["cogs_ratio"]).round(2)
        data["estimated_profit"] = (data["total_amount"] - data["estimated_cost"]).round(2)
        data["profit_margin_pct"] = np.where(
            data["total_amount"] > 0,
            ((data["estimated_profit"] / data["total_amount"]) * 100).round(2),
            0.0
        )

    # 5. Demographic Cohorts
    if "age" in data.columns:
        data["age"] = pd.to_numeric(data["age"], errors="coerce").fillna(data["age"].median()).astype(int)
        data["age_group"] = create_age_groups(data["age"])

    # 6. Clean Text Dimensions
    text_cols = ["gender", "product_category", "product_name", "payment_method", "region", "store_id"]
    for col in text_cols:
        if col in data.columns:
            data[col] = data[col].astype(str).str.strip()

    # 7. Deduplicate & sort chronologically
    data = data.drop_duplicates(subset=["transaction_id"] if "transaction_id" in data.columns else None)
    if "date" in data.columns:
        data = data.sort_values(by="date").reset_index(drop=True)

    return data


def run_processing_pipeline(
    raw_filename: str = "retail_sales_dataset.csv",
    output_filename: str = "cleaned_retail_sales.csv"
) -> Path:
    """
    Executes end-to-end cleaning and saves output to data/processed/.
    """
    print("=" * 60)
    print("🚀 EXECUTING STEP 2: DATA CLEANING & FEATURE ENGINEERING")
    print("=" * 60)

    print(f"Reading raw data: {raw_filename}...")
    raw_df = load_raw_data(raw_filename)
    print(f"Raw shape: {raw_df.shape[0]} rows, {raw_df.shape[1]} columns")

    print("Transforming & engineering features...")
    processed_df = process_sales_data(raw_df)
    print(f"Processed shape: {processed_df.shape[0]} rows, {processed_df.shape[1]} columns")

    out_dir = get_processed_data_dir()
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / output_filename

    processed_df.to_csv(out_path, index=False)
    print(f"✅ Processed dataset saved successfully to:\n   {out_path}")

    print("\n--- NEWLY ENGINEERED FEATURES ---")
    new_cols = [c for c in processed_df.columns if c not in [x.lower() for x in raw_df.columns]]
    for col in new_cols:
        print(f"  + {col:<20} | Sample: {processed_df[col].iloc[0]}")

    print("\n" + "=" * 60)
    print("STEP 2 COMPLETE: Processed dataset ready for Analytics & Dashboard!")
    print("=" * 60)
    return out_path


if __name__ == "__main__":
    if sys.platform == "win32":
        sys.stdout.reconfigure(encoding="utf-8")
    run_processing_pipeline()
