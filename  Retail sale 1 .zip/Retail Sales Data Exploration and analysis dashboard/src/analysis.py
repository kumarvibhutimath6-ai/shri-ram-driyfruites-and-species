"""
Core Analytics & KPI Calculation Engine
Computes executive retail metrics, time-series aggregations, product performance,
customer demographic breakdowns, and RFM customer segmentation.
"""

from typing import Dict, Any, Optional
import numpy as np
import pandas as pd


def compute_executive_kpis(df: pd.DataFrame) -> Dict[str, Any]:
    """
    Computes top-level executive KPIs.
    """
    if df.empty:
        return {
            "total_revenue": 0.0,
            "gross_revenue": 0.0,
            "total_discounts": 0.0,
            "discount_rate_pct": 0.0,
            "estimated_profit": 0.0,
            "profit_margin_pct": 0.0,
            "total_orders": 0,
            "total_units": 0,
            "average_order_value": 0.0,
            "units_per_order": 0.0,
            "unique_customers": 0,
            "average_rating": 0.0
        }

    total_revenue = float(df["total_amount"].sum()) if "total_amount" in df.columns else 0.0
    gross_revenue = float(df["gross_amount"].sum()) if "gross_amount" in df.columns else total_revenue
    total_discounts = float(df["discount_amount"].sum()) if "discount_amount" in df.columns else 0.0
    discount_rate = (total_discounts / gross_revenue * 100) if gross_revenue > 0 else 0.0

    estimated_profit = float(df["estimated_profit"].sum()) if "estimated_profit" in df.columns else 0.0
    profit_margin = (estimated_profit / total_revenue * 100) if total_revenue > 0 else 0.0

    total_orders = len(df)
    total_units = int(df["quantity"].sum()) if "quantity" in df.columns else total_orders
    aov = total_revenue / total_orders if total_orders > 0 else 0.0
    upt = total_units / total_orders if total_orders > 0 else 0.0
    
    unique_cust = int(df["customer_id"].nunique()) if "customer_id" in df.columns else total_orders
    avg_rating = float(df["customer_rating"].mean()) if "customer_rating" in df.columns else 0.0

    return {
        "total_revenue": round(total_revenue, 2),
        "gross_revenue": round(gross_revenue, 2),
        "total_discounts": round(total_discounts, 2),
        "discount_rate_pct": round(discount_rate, 2),
        "estimated_profit": round(estimated_profit, 2),
        "profit_margin_pct": round(profit_margin, 2),
        "total_orders": total_orders,
        "total_units": total_units,
        "average_order_value": round(aov, 2),
        "units_per_order": round(upt, 2),
        "unique_customers": unique_cust,
        "average_rating": round(avg_rating, 2)
    }


def get_monthly_sales_trend(df: pd.DataFrame) -> pd.DataFrame:
    """
    Groups data by year_month and computes revenue, profit, orders, and MoM growth rate.
    """
    if df.empty or "year_month" not in df.columns:
        return pd.DataFrame()

    monthly = df.groupby("year_month").agg(
        revenue=("total_amount", "sum"),
        profit=("estimated_profit", "sum") if "estimated_profit" in df.columns else ("total_amount", "sum"),
        orders=("transaction_id", "count") if "transaction_id" in df.columns else ("date", "count"),
        units=("quantity", "sum") if "quantity" in df.columns else ("total_amount", "count")
    ).reset_index()

    monthly["mom_growth_pct"] = monthly["revenue"].pct_change() * 100
    monthly["mom_growth_pct"] = monthly["mom_growth_pct"].fillna(0.0).round(2)
    return monthly


def get_category_performance(df: pd.DataFrame) -> pd.DataFrame:
    """
    Aggregates product category metrics: Revenue, Profit, Units, Orders, Margin %.
    """
    if df.empty or "product_category" not in df.columns:
        return pd.DataFrame()

    cat_df = df.groupby("product_category").agg(
        revenue=("total_amount", "sum"),
        profit=("estimated_profit", "sum") if "estimated_profit" in df.columns else ("total_amount", "sum"),
        orders=("total_amount", "count"),
        units=("quantity", "sum") if "quantity" in df.columns else ("total_amount", "count"),
        avg_price=("price_per_unit", "mean") if "price_per_unit" in df.columns else ("total_amount", "mean"),
        avg_rating=("customer_rating", "mean") if "customer_rating" in df.columns else ("total_amount", "mean")
    ).reset_index()

    cat_df["revenue_share_pct"] = (cat_df["revenue"] / cat_df["revenue"].sum() * 100).round(2)
    cat_df["profit_margin_pct"] = (cat_df["profit"] / cat_df["revenue"] * 100).round(2)
    return cat_df.sort_values(by="revenue", ascending=False)


def get_top_products(df: pd.DataFrame, top_n: int = 10) -> pd.DataFrame:
    """
    Computes top-selling products by revenue and quantity.
    """
    if df.empty or "product_name" not in df.columns:
        return pd.DataFrame()

    prod_df = df.groupby(["product_category", "product_name"]).agg(
        revenue=("total_amount", "sum"),
        units_sold=("quantity", "sum"),
        orders=("total_amount", "count"),
        avg_price=("price_per_unit", "mean")
    ).reset_index()

    return prod_df.sort_values(by="revenue", ascending=False).head(top_n)


def get_customer_demographic_insights(df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    """
    Provides age group, gender, and combined spending profiles.
    """
    if df.empty:
        return {}

    by_age = pd.DataFrame()
    if "age_group" in df.columns:
        by_age = df.groupby("age_group", observed=True).agg(
            revenue=("total_amount", "sum"),
            orders=("total_amount", "count"),
            aov=("total_amount", "mean")
        ).reset_index()

    by_gender = pd.DataFrame()
    if "gender" in df.columns:
        by_gender = df.groupby("gender").agg(
            revenue=("total_amount", "sum"),
            orders=("total_amount", "count"),
            aov=("total_amount", "mean")
        ).reset_index()

    return {"by_age": by_age, "by_gender": by_gender}


def get_regional_performance(df: pd.DataFrame) -> pd.DataFrame:
    """
    Aggregates performance by geographic region and stores.
    """
    if df.empty or "region" not in df.columns:
        return pd.DataFrame()

    reg_df = df.groupby("region").agg(
        revenue=("total_amount", "sum"),
        orders=("total_amount", "count"),
        units=("quantity", "sum"),
        avg_rating=("customer_rating", "mean")
    ).reset_index()

    reg_df["revenue_share_pct"] = (reg_df["revenue"] / reg_df["revenue"].sum() * 100).round(2)
    return reg_df.sort_values(by="revenue", ascending=False)


def compute_rfm_segments(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculates Recency, Frequency, Monetary (RFM) customer segmentation.
    """
    if df.empty or "customer_id" not in df.columns or "date" not in df.columns:
        return pd.DataFrame()

    temp_df = df.copy()
    temp_df["date"] = pd.to_datetime(temp_df["date"])
    snapshot_date = temp_df["date"].max() + pd.Timedelta(days=1)

    rfm = temp_df.groupby("customer_id").agg(
        recency=("date", lambda d: (snapshot_date - d.max()).days),
        frequency=("transaction_id", "count") if "transaction_id" in temp_df.columns else ("date", "count"),
        monetary=("total_amount", "sum")
    ).reset_index()

    # Assign quantile scores (1 to 4)
    rfm["r_score"] = pd.qcut(rfm["recency"], 4, labels=[4, 3, 2, 1], duplicates="drop").astype(int)
    rfm["f_score"] = pd.qcut(rfm["frequency"].rank(method="first"), 4, labels=[1, 2, 3, 4]).astype(int)
    rfm["m_score"] = pd.qcut(rfm["monetary"], 4, labels=[1, 2, 3, 4], duplicates="drop").astype(int)

    rfm["rfm_score"] = rfm["r_score"].astype(str) + rfm["f_score"].astype(str) + rfm["m_score"].astype(str)

    # Segment mapping based on R and M
    def segment_label(row):
        r, m = row["r_score"], row["m_score"]
        if r >= 3 and m >= 3:
            return "Champion / High Value"
        elif r >= 3 and m < 3:
            return "Loyal / Active"
        elif r < 3 and m >= 3:
            return "At Risk (High Spend)"
        else:
            return "Hibernating / Low Value"

    rfm["customer_segment"] = rfm.apply(segment_label, axis=1)
    return rfm
