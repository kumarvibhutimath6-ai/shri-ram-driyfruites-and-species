"""
Synthetic Retail Sales Data Generator (Standard Library - Zero External Dependencies)
Generates 2,000 realistic retail sales transactions into data/raw/retail_sales_dataset.csv
"""

import os
import csv
import random
from datetime import datetime, timedelta


def generate_dataset(num_records: int = 2000, seed: int = 42):
    random.seed(seed)

    categories = {
        "Electronics": [
            ("Smartphone", 500, 1100),
            ("Laptop", 750, 1800),
            ("Headphones", 45, 220),
            ("Smartwatch", 120, 350),
            ("Tablet", 250, 650)
        ],
        "Clothing": [
            ("Jeans", 35, 90),
            ("T-Shirt", 15, 40),
            ("Jacket", 80, 200),
            ("Sneakers", 55, 160),
            ("Dress", 45, 130)
        ],
        "Beauty & Personal Care": [
            ("Skincare Set", 30, 110),
            ("Perfume", 40, 150),
            ("Lipstick", 15, 35),
            ("Hair Dryer", 35, 95)
        ],
        "Home & Kitchen": [
            ("Coffee Maker", 40, 140),
            ("Blender", 30, 85),
            ("Cookware Set", 65, 220),
            ("Vacuum Cleaner", 85, 280)
        ],
        "Books & Stationery": [
            ("Bestseller Novel", 12, 28),
            ("Notebook Set", 8, 22),
            ("Art Supplies Kit", 20, 55)
        ]
    }

    genders = ["Male", "Female", "Other"]
    gender_weights = [0.48, 0.48, 0.04]

    payment_methods = ["Credit Card", "Debit Card", "Cash", "Digital Wallet"]
    payment_weights = [0.45, 0.25, 0.12, 0.18]

    regions = ["North America", "Europe", "Asia-Pacific", "Latin America", "Middle East"]
    region_weights = [0.35, 0.30, 0.20, 0.10, 0.05]

    start_date = datetime(2023, 1, 1)
    end_date = datetime(2024, 12, 31)
    date_range_days = (end_date - start_date).days

    cat_list = list(categories.keys())
    cat_weights = [0.25, 0.30, 0.20, 0.15, 0.10]

    rows = []

    for i in range(1, num_records + 1):
        txn_id = f"TXN-{100000 + i}"
        cust_id = f"CUST-{random.randint(1001, 1500)}"
        txn_date = start_date + timedelta(days=random.randint(0, date_range_days))
        gender = random.choices(genders, weights=gender_weights, k=1)[0]
        age = random.randint(18, 68)

        category = random.choices(cat_list, weights=cat_weights, k=1)[0]
        product_info = random.choice(categories[category])
        product_name = product_info[0]
        price_per_unit = round(random.uniform(product_info[1], product_info[2]), 2)

        if category in ["Electronics", "Home & Kitchen"]:
            quantity = random.choices([1, 2, 3], weights=[0.80, 0.17, 0.03], k=1)[0]
        else:
            quantity = random.choices([1, 2, 3, 4, 5], weights=[0.40, 0.30, 0.15, 0.10, 0.05], k=1)[0]

        discount_percent = random.choice([0, 0, 0, 5, 10, 15, 20])
        gross = round(price_per_unit * quantity, 2)
        discount = round(gross * (discount_percent / 100.0), 2)
        total_amount = round(gross - discount, 2)

        payment_method = random.choices(payment_methods, weights=payment_weights, k=1)[0]
        region = random.choices(regions, weights=region_weights, k=1)[0]
        store_id = f"STR-{random.randint(101, 120):03d}"
        rating = random.choices([1, 2, 3, 4, 5], weights=[0.05, 0.07, 0.18, 0.35, 0.35], k=1)[0]

        rows.append({
            "Transaction_ID": txn_id,
            "Date": txn_date.strftime("%Y-%m-%d"),
            "Customer_ID": cust_id,
            "Gender": gender,
            "Age": age,
            "Product_Category": category,
            "Product_Name": product_name,
            "Quantity": quantity,
            "Price_per_Unit": price_per_unit,
            "Discount_Percent": discount_percent,
            "Total_Amount": total_amount,
            "Payment_Method": payment_method,
            "Region": region,
            "Store_ID": store_id,
            "Customer_Rating": rating
        })

    # Sort chronologically by date
    rows.sort(key=lambda x: x["Date"])

    output_dir = os.path.join(os.path.dirname(__file__), "..", "data", "raw")
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "retail_sales_dataset.csv")

    with open(output_path, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    print(f"Generated {len(rows)} retail transactions at: {output_path}")


if __name__ == "__main__":
    generate_dataset()
