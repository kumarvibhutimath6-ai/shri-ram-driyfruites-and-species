"""
Retail Sales Data Exploration & Analysis Dashboard
A modern, production-grade interactive analytics web app powered by Streamlit & Plotly.
Run with: streamlit run src/dashboard.py
"""

import sys
from pathlib import Path
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# Set project paths
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.append(str(ROOT_DIR))

from src.data_loader import load_processed_data, get_processed_data_dir
from src.data_processing import process_sales_data, run_processing_pipeline
from src.analysis import (
    compute_executive_kpis,
    get_monthly_sales_trend,
    get_category_performance,
    get_top_products,
    get_customer_demographic_insights,
    get_regional_performance,
    compute_rfm_segments
)
from src.utils import format_currency, format_number

# -----------------------------------------------------------------------------
# PAGE CONFIGURATION & THEME STYLING
# -----------------------------------------------------------------------------
st.set_page_config(
    page_title="Retail Sales Analytics Dashboard",
    page_icon="🛍️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for rich aesthetics and responsive cards
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

    html, body, [class*="css"] {
        font-family: 'Plus Jakarta Sans', sans-serif;
    }

    /* Metric Card Styling */
    .metric-box {
        background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 16px 20px;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
        margin-bottom: 12px;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .metric-box:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.08);
    }
    .metric-title {
        color: #64748b;
        font-size: 0.85rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 4px;
    }
    .metric-value {
        color: #0f172a;
        font-size: 1.65rem;
        font-weight: 800;
        margin-bottom: 2px;
    }
    .metric-subtitle {
        color: #10b981;
        font-size: 0.8rem;
        font-weight: 600;
    }

    /* Custom Header Banner */
    .header-banner {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
        color: #ffffff;
        padding: 24px 30px;
        border-radius: 16px;
        margin-bottom: 24px;
        box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.3);
    }
    .header-title {
        font-size: 1.8rem;
        font-weight: 800;
        margin: 0;
        letter-spacing: -0.02em;
    }
    .header-desc {
        color: #94a3b8;
        font-size: 0.95rem;
        margin-top: 6px;
    }
</style>
""", unsafe_allow_html=True)


# -----------------------------------------------------------------------------
# DATA LOADING & CACHING
# -----------------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def get_dashboard_data() -> pd.DataFrame:
    try:
        df = load_processed_data("cleaned_retail_sales.csv")
    except Exception:
        # Fallback to run processing pipeline automatically
        run_processing_pipeline()
        df = load_processed_data("cleaned_retail_sales.csv")

    df["date"] = pd.to_datetime(df["date"])
    return df


df_raw = get_dashboard_data()


# -----------------------------------------------------------------------------
# SIDEBAR FILTERS
# -----------------------------------------------------------------------------
with st.sidebar:
    st.image("https://images.unsplash.com/photo-1556742049-0a67e55722c3?w=300&auto=format&fit=crop&q=60", use_container_width=True)
    st.title("⚙️ Control Panel")
    st.markdown("Filter sales metrics by timeline, category, and geography.")

    # 1. Date Range
    min_date = df_raw["date"].min().date()
    max_date = df_raw["date"].max().date()

    date_range = st.date_input(
        "📅 Date Range",
        value=(min_date, max_date),
        min_value=min_date,
        max_value=max_date
    )

    # 2. Product Category Filter
    all_categories = sorted(df_raw["product_category"].unique())
    selected_categories = st.multiselect(
        "🛍️ Product Category",
        options=all_categories,
        default=all_categories
    )

    # 3. Region Filter
    all_regions = sorted(df_raw["region"].unique())
    selected_regions = st.multiselect(
        "🌍 Geographic Region",
        options=all_regions,
        default=all_regions
    )

    # 4. Payment Method
    all_payments = sorted(df_raw["payment_method"].unique())
    selected_payments = st.multiselect(
        "💳 Payment Method",
        options=all_payments,
        default=all_payments
    )

    # 5. Customer Demographics
    all_age_groups = sorted([str(x) for x in df_raw["age_group"].dropna().unique()])
    selected_age_groups = st.multiselect(
        "👥 Age Cohorts",
        options=all_age_groups,
        default=all_age_groups
    )

    all_genders = sorted(df_raw["gender"].unique())
    selected_genders = st.multiselect(
        "⚧️ Gender",
        options=all_genders,
        default=all_genders
    )

    st.divider()
    st.caption("Retail Sales Exploration Engine v2.0")


# -----------------------------------------------------------------------------
# APPLY FILTER LOGIC
# -----------------------------------------------------------------------------
filtered_df = df_raw.copy()

if isinstance(date_range, tuple) and len(date_range) == 2:
    start_d, end_d = date_range
    filtered_df = filtered_df[
        (filtered_df["date"].dt.date >= start_d) & (filtered_df["date"].dt.date <= end_d)
    ]

if selected_categories:
    filtered_df = filtered_df[filtered_df["product_category"].isin(selected_categories)]

if selected_regions:
    filtered_df = filtered_df[filtered_df["region"].isin(selected_regions)]

if selected_payments:
    filtered_df = filtered_df[filtered_df["payment_method"].isin(selected_payments)]

if selected_age_groups:
    filtered_df = filtered_df[filtered_df["age_group"].astype(str).isin(selected_age_groups)]

if selected_genders:
    filtered_df = filtered_df[filtered_df["gender"].isin(selected_genders)]


# -----------------------------------------------------------------------------
# HEADER BANNER
# -----------------------------------------------------------------------------
st.markdown(f"""
<div class="header-banner">
    <h1 class="header-title">🛍️ Retail Sales Data Exploration & Analysis Dashboard</h1>
    <div class="header-desc">
        Comprehensive multi-dimensional intelligence platform • Showing <strong>{len(filtered_df):,}</strong> of <strong>{len(df_raw):,}</strong> recorded transactions
    </div>
</div>
""", unsafe_allow_html=True)


if filtered_df.empty:
    st.warning("⚠️ No transactions match your selected filter criteria. Please adjust your filters.")
    st.stop()


# -----------------------------------------------------------------------------
# TOP METRIC CARDS ROW
# -----------------------------------------------------------------------------
kpis = compute_executive_kpis(filtered_df)

c1, c2, c3, c4, c5 = st.columns(5)

with c1:
    st.markdown(f"""
    <div class="metric-box">
        <div class="metric-title">Net Sales Revenue</div>
        <div class="metric-value">{format_currency(kpis['total_revenue'])}</div>
        <div class="metric-subtitle">Gross: {format_currency(kpis['gross_revenue'])}</div>
    </div>
    """, unsafe_allow_html=True)

with c2:
    st.markdown(f"""
    <div class="metric-box">
        <div class="metric-title">Estimated Profit</div>
        <div class="metric-value">{format_currency(kpis['estimated_profit'])}</div>
        <div class="metric-subtitle">{kpis['profit_margin_pct']}% Gross Margin</div>
    </div>
    """, unsafe_allow_html=True)

with c3:
    st.markdown(f"""
    <div class="metric-box">
        <div class="metric-title">Total Orders</div>
        <div class="metric-value">{format_number(kpis['total_orders'])}</div>
        <div class="metric-subtitle">{format_number(kpis['total_units'])} Units Sold</div>
    </div>
    """, unsafe_allow_html=True)

with c4:
    st.markdown(f"""
    <div class="metric-box">
        <div class="metric-title">Avg Order Value (AOV)</div>
        <div class="metric-value">{format_currency(kpis['average_order_value'])}</div>
        <div class="metric-subtitle">{kpis['units_per_order']} Units / Order</div>
    </div>
    """, unsafe_allow_html=True)

with c5:
    st.markdown(f"""
    <div class="metric-box">
        <div class="metric-title">Customer Satisfaction</div>
        <div class="metric-value">★ {kpis['average_rating']} / 5.0</div>
        <div class="metric-subtitle">{format_number(kpis['unique_customers'])} Unique Buyers</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)


# -----------------------------------------------------------------------------
# MAIN DASHBOARD TABS
# -----------------------------------------------------------------------------
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "📈 Sales & Revenue Trends",
    "🛍️ Product & Categories",
    "👥 Customer & RFM Intelligence",
    "🌍 Regional & Channels",
    "📑 Data Explorer & Export"
])


# =============================================================================
# TAB 1: SALES & REVENUE TRENDS
# =============================================================================
with tab1:
    col_t1, col_t2 = st.columns([2, 1])

    with col_t1:
        monthly_trend = get_monthly_sales_trend(filtered_df)
        if not monthly_trend.empty:
            fig_trend = go.Figure()
            fig_trend.add_trace(go.Scatter(
                x=monthly_trend["year_month"],
                y=monthly_trend["revenue"],
                name="Revenue ($)",
                mode="lines+markers",
                line=dict(color="#2563eb", width=3),
                fill="tozeroy",
                fillcolor="rgba(37, 99, 235, 0.1)"
            ))
            fig_trend.add_trace(go.Scatter(
                x=monthly_trend["year_month"],
                y=monthly_trend["profit"],
                name="Est. Profit ($)",
                mode="lines+markers",
                line=dict(color="#10b981", width=2, dash="dot")
            ))
            fig_trend.update_layout(
                title="<b>Monthly Revenue vs. Estimated Profit Timeline</b>",
                xaxis_title="Year-Month",
                yaxis_title="Amount ($)",
                hovermode="x unified",
                template="plotly_white",
                margin=dict(l=20, r=20, t=50, b=20),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
            )
            st.plotly_chart(fig_trend, use_container_width=True)

    with col_t2:
        # Quarterly Comparison
        if "year_quarter" in filtered_df.columns:
            quarterly = filtered_df.groupby("year_quarter")["total_amount"].sum().reset_index()
            fig_quarter = px.bar(
                quarterly,
                x="year_quarter",
                y="total_amount",
                title="<b>Quarterly Sales Performance</b>",
                labels={"total_amount": "Revenue ($)", "year_quarter": "Quarter"},
                color="total_amount",
                color_continuous_scale="Blues",
                template="plotly_white"
            )
            fig_quarter.update_layout(showlegend=False, margin=dict(l=20, r=20, t=50, b=20))
            st.plotly_chart(fig_quarter, use_container_width=True)

    # Day of Week & Weekend Behavior
    col_w1, col_w2 = st.columns(2)
    with col_w1:
        day_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        dow_df = filtered_df.groupby("day_name")["total_amount"].agg(["sum", "count"]).reindex(day_order).reset_index()
        fig_dow = px.bar(
            dow_df,
            x="day_name",
            y="sum",
            title="<b>Sales Distribution by Day of Week</b>",
            labels={"day_name": "Day", "sum": "Total Revenue ($)"},
            color="sum",
            color_continuous_scale="Viridis",
            template="plotly_white"
        )
        st.plotly_chart(fig_dow, use_container_width=True)

    with col_w2:
        monthly_growth = monthly_trend[["year_month", "mom_growth_pct"]] if not monthly_trend.empty else pd.DataFrame()
        if not monthly_growth.empty:
            fig_growth = px.bar(
                monthly_growth,
                x="year_month",
                y="mom_growth_pct",
                title="<b>Month-over-Month (MoM) Revenue Growth %</b>",
                labels={"year_month": "Month", "mom_growth_pct": "Growth (%)"},
                color="mom_growth_pct",
                color_continuous_scale="RdYlGn",
                template="plotly_white"
            )
            fig_growth.update_layout(margin=dict(l=20, r=20, t=50, b=20))
            st.plotly_chart(fig_growth, use_container_width=True)


# =============================================================================
# TAB 2: PRODUCT & CATEGORY ANALYTICS
# =============================================================================
with tab2:
    col_p1, col_p2 = st.columns([1, 1])

    with col_p1:
        cat_perf = get_category_performance(filtered_df)
        if not cat_perf.empty:
            fig_cat = px.bar(
                cat_perf,
                x="product_category",
                y="revenue",
                color="profit_margin_pct",
                title="<b>Category Revenue & Profit Margin (%)</b>",
                labels={"revenue": "Revenue ($)", "profit_margin_pct": "Margin %", "product_category": "Category"},
                color_continuous_scale="Teal",
                template="plotly_white",
                text_auto=".2s"
            )
            fig_cat.update_layout(margin=dict(l=20, r=20, t=50, b=20))
            st.plotly_chart(fig_cat, use_container_width=True)

    with col_p2:
        # Treemap
        fig_tree = px.treemap(
            filtered_df,
            path=["product_category", "product_name"],
            values="total_amount",
            title="<b>Product Hierarchy Sales Treemap</b>",
            color="total_amount",
            color_continuous_scale="Blues",
            template="plotly_white"
        )
        fig_tree.update_layout(margin=dict(l=10, r=10, t=50, b=10))
        st.plotly_chart(fig_tree, use_container_width=True)

    st.subheader("🏆 Top Best-Selling Products")
    top_items = get_top_products(filtered_df, top_n=10)
    if not top_items.empty:
        col_t1, col_t2 = st.columns([2, 1])
        with col_t1:
            fig_top = px.bar(
                top_items,
                x="revenue",
                y="product_name",
                orientation="h",
                color="product_category",
                title="<b>Top 10 Products by Total Net Revenue</b>",
                labels={"revenue": "Revenue ($)", "product_name": "Product"},
                template="plotly_white"
            )
            fig_top.update_layout(yaxis=dict(autorange="reversed"), margin=dict(l=20, r=20, t=50, b=20))
            st.plotly_chart(fig_top, use_container_width=True)
        with col_t2:
            st.dataframe(
                top_items[["product_name", "product_category", "revenue", "units_sold", "avg_price"]].rename(
                    columns={
                        "product_name": "Product",
                        "product_category": "Category",
                        "revenue": "Revenue ($)",
                        "units_sold": "Units",
                        "avg_price": "Avg Price ($)"
                    }
                ).style.format({"Revenue ($)": "${:,.2f}", "Avg Price ($)": "${:,.2f}", "Units": "{:,}"}),
                use_container_width=True,
                height=350
            )


# =============================================================================
# TAB 3: CUSTOMER & RFM INTELLIGENCE
# =============================================================================
with tab3:
    col_c1, col_c2 = st.columns(2)

    with col_c1:
        # Age group vs Gender
        if "age_group" in filtered_df.columns and "gender" in filtered_df.columns:
            age_gender = filtered_df.groupby(["age_group", "gender"], observed=True)["total_amount"].sum().reset_index()
            fig_ag = px.bar(
                age_gender,
                x="age_group",
                y="total_amount",
                color="gender",
                barmode="group",
                title="<b>Spending by Customer Age Cohort & Gender</b>",
                labels={"age_group": "Age Group", "total_amount": "Total Revenue ($)", "gender": "Gender"},
                color_discrete_sequence=px.colors.qualitative.Safe,
                template="plotly_white"
            )
            st.plotly_chart(fig_ag, use_container_width=True)

    with col_c2:
        # Customer Ratings Distribution
        if "customer_rating" in filtered_df.columns:
            rating_counts = filtered_df["customer_rating"].value_counts().sort_index().reset_index()
            rating_counts.columns = ["Rating", "Count"]
            rating_counts["Rating_Label"] = rating_counts["Rating"].apply(lambda r: f"★ {r} Star{'s' if r>1 else ''}")
            fig_rating = px.pie(
                rating_counts,
                names="Rating_Label",
                values="Count",
                title="<b>Customer Satisfaction Rating Breakdown</b>",
                color_discrete_sequence=px.colors.sequential.Sunset,
                template="plotly_white",
                hole=0.45
            )
            st.plotly_chart(fig_rating, use_container_width=True)

    # RFM Customer Segmentation
    st.subheader("🎯 RFM (Recency, Frequency, Monetary) Customer Segmentation")
    rfm_df = compute_rfm_segments(filtered_df)
    if not rfm_df.empty:
        col_rfm1, col_rfm2 = st.columns([1, 2])
        with col_rfm1:
            segment_counts = rfm_df["customer_segment"].value_counts().reset_index()
            segment_counts.columns = ["Segment", "Count"]
            fig_rfm = px.pie(
                segment_counts,
                names="Segment",
                values="Count",
                title="<b>Customer Segment Distribution</b>",
                hole=0.4,
                color_discrete_sequence=px.colors.qualitative.Prism,
                template="plotly_white"
            )
            st.plotly_chart(fig_rfm, use_container_width=True)
        with col_rfm2:
            st.markdown("##### 👥 High-Value Customer Leaderboard")
            top_rfm_cust = rfm_df.sort_values(by="monetary", ascending=False).head(8)
            st.dataframe(
                top_rfm_cust.rename(
                    columns={
                        "customer_id": "Customer ID",
                        "recency": "Recency (Days)",
                        "frequency": "Total Orders",
                        "monetary": "Total Spend ($)",
                        "customer_segment": "Segment"
                    }
                ).style.format({"Total Spend ($)": "${:,.2f}"}),
                use_container_width=True,
                height=290
            )


# =============================================================================
# TAB 4: REGIONAL & CHANNEL INSIGHTS
# =============================================================================
with tab4:
    col_r1, col_r2 = st.columns(2)

    with col_r1:
        reg_data = get_regional_performance(filtered_df)
        if not reg_data.empty:
            fig_reg = px.pie(
                reg_data,
                names="region",
                values="revenue",
                title="<b>Global Regional Revenue Share</b>",
                hole=0.4,
                color_discrete_sequence=px.colors.sequential.dense,
                template="plotly_white"
            )
            st.plotly_chart(fig_reg, use_container_width=True)

    with col_r2:
        # Payment Method Breakdown
        if "payment_method" in filtered_df.columns:
            pay_df = filtered_df.groupby("payment_method").agg(
                revenue=("total_amount", "sum"),
                orders=("total_amount", "count")
            ).reset_index()
            fig_pay = px.bar(
                pay_df,
                x="payment_method",
                y="revenue",
                title="<b>Revenue by Payment Method Channel</b>",
                labels={"payment_method": "Payment Method", "revenue": "Revenue ($)"},
                color="payment_method",
                template="plotly_white"
            )
            fig_pay.update_layout(showlegend=False)
            st.plotly_chart(fig_pay, use_container_width=True)

    # Store Comparison
    if "store_id" in filtered_df.columns:
        st.subheader("🏪 Top Store Outlets Ranking")
        store_df = filtered_df.groupby(["store_id", "region"]).agg(
            revenue=("total_amount", "sum"),
            orders=("total_amount", "count"),
            avg_rating=("customer_rating", "mean")
        ).reset_index().sort_values(by="revenue", ascending=False).head(10)

        fig_store = px.bar(
            store_df,
            x="store_id",
            y="revenue",
            color="region",
            title="<b>Top 10 Stores by Revenue & Region</b>",
            labels={"store_id": "Store Outlet", "revenue": "Revenue ($)", "region": "Region"},
            template="plotly_white"
        )
        st.plotly_chart(fig_store, use_container_width=True)


# =============================================================================
# TAB 5: DATA EXPLORER & EXPORT
# =============================================================================
with tab5:
    st.subheader("🔍 Filtered Transactions Explorer")
    st.markdown("Inspect granular records and export filtered or full datasets.")

    col_s1, col_s2 = st.columns([3, 1])
    with col_s1:
        search_query = st.text_input("🔎 Search by Transaction ID, Customer ID, or Product Name:", "")
    with col_s2:
        row_limit = st.selectbox("Display Rows:", [25, 50, 100, 200, 500], index=1)

    display_df = filtered_df.copy()
    if search_query:
        display_df = display_df[
            display_df["transaction_id"].str.contains(search_query, case=False, na=False) |
            display_df["customer_id"].str.contains(search_query, case=False, na=False) |
            display_df["product_name"].str.contains(search_query, case=False, na=False)
        ]

    st.dataframe(
        display_df.head(row_limit),
        use_container_width=True,
        height=380
    )

    # Export Buttons
    col_d1, col_d2 = st.columns([1, 4])
    with col_d1:
        csv_data = filtered_df.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="⬇️ Download Filtered CSV",
            data=csv_data,
            file_name="filtered_retail_sales.csv",
            mime="text/csv",
            use_container_width=True
        )
