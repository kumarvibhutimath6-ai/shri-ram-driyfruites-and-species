"""
Utilities Module
Formatting, chart themes, and helper functions.
"""

from typing import Union


def format_currency(value: Union[int, float], currency_symbol: str = "$") -> str:
    """Formats a number as a readable currency string."""
    if value >= 1_000_000:
        return f"{currency_symbol}{value / 1_000_000:.2f}M"
    elif value >= 1_000:
        return f"{currency_symbol}{value / 1_000:.2f}K"
    return f"{currency_symbol}{value:,.2f}"


def format_number(value: Union[int, float]) -> str:
    """Formats integers / floats with commas and abbreviations."""
    if value >= 1_000_000:
        return f"{value / 1_000_000:.2f}M"
    elif value >= 1_000:
        return f"{value / 1_000:.2f}K"
    return f"{value:,.0f}"
