# 📐 Retail Sales Data Exploration & Analysis Dashboard — Project Blueprint

An architectural blueprint and execution guide for building, analyzing, and deploying an end-to-end retail sales analytics platform.

---

## 📑 Table of Contents
1. [Project Overview & Objectives](#1-project-overview--objectives)
2. [Architecture & Pipeline Flow](#2-architecture--pipeline-flow)
3. [Data Dictionary & Schema Specs](#3-data-dictionary--schema-specs)
4. [Step-by-Step Build Roadmap](#4-step-by-step-build-roadmap)
5. [KPIs & Mathematical Formulations](#5-kpis--mathematical-formulations)
6. [Interactive Dashboard UI/UX Design](#6-interactive-dashboard-uiux-design)
7. [Technology Stack](#7-technology-stack)
8. [Execution Commands & Quick Reference](#8-execution-commands--quick-reference)

---

## 1. Project Overview & Objectives

### 🎯 Primary Goals
* **Understand Revenue Drivers**: Analyze sales performance across product lines, customer segments, seasons, and geographic regions.
* **Customer Profiling**: Uncover purchasing patterns across demographics (Age, Gender) and payment preferences.
* **Operational Performance**: Evaluate store-level sales efficiency, discount impacts, and customer satisfaction ratings.
* **Executive Decision Support**: Deliver a modern, interactive web dashboard with dynamic filtering, real-time KPI calculations, and Plotly visualizations.

---

## 2. Architecture & Pipeline Flow

```mermaid
flowchart TD
    subgraph S1["Step 1: Ingestion Layer"]
        A["Raw Data Sources\n(CSV / Excel / Parquet)"] --> B["Data Loader & Validator\n(src/data_loader.py)"]
        B --> C["data/raw/retail_sales_dataset.csv"]
    end

    subgraph S2["Step 2: Processing Layer"]
        C --> D["Cleaning & Feature Engineering\n(src/data_processing.py)"]
        D --> E["data/processed/cleaned_retail_sales.csv"]
    end

    subgraph S3["Step 3: Exploration & Analysis"]
        E --> F["EDA Notebooks\n(notebooks/01_retail_sales_eda.ipynb)"]
        E --> G["Analytics & KPI Engine\n(src/analysis.py)"]
    end

    subgraph S4["Step 4: Interactive Presentation"]
        G --> H["Streamlit Web Dashboard\n(src/dashboard.py)"]
        H --> I["Plotly Interactive Visualizations"]
        H --> J["Dynamic Filters & Export Tools"]
    end
```

---

## 3. Data Dictionary & Schema Specs

### 📥 Raw Transaction Schema (`data/raw/`)

| Field Name | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `Transaction_ID` | String | Unique, Non-null | Primary key identifier (e.g. `TXN-101076`) |
| `Date` | Date | `YYYY-MM-DD` | Date of sale |
| `Customer_ID` | String | Non-null | Customer identifier (e.g. `CUST-1154`) |
| `Gender` | Categorical | `Male`, `Female`, `Other` | Demographic gender |
| `Age` | Integer | `18 <= Age <= 70` | Customer age |
| `Product_Category` | Categorical | 5 categories | Main product category |
| `Product_Name` | String | Non-null | Specific item sold |
| `Quantity` | Integer | `Quantity >= 1` | Number of units purchased |
| `Price_per_Unit` | Float | `> 0.0` | Base price per unit ($) |
| `Discount_Percent` | Integer | `0, 5, 10, 15, 20` | Discount applied (%) |
| `Total_Amount` | Float | Calculated | Net transaction total after discount ($) |
| `Payment_Method` | Categorical | 4 types | Payment channel used |
| `Region` | Categorical | 5 global regions | Store geographic territory |
| `Store_ID` | String | Non-null | Retail outlet ID (`STR-101` - `STR-120`) |
| `Customer_Rating` | Integer | `1 <= Rating <= 5` | Post-purchase feedback score |

---

### ⚙️ Engineered Features (`data/processed/`)

| New Feature | Formula / Origin | Purpose |
| :--- | :--- | :--- |
| `Year` | `dt.year` | Annual aggregation |
| `Month` / `Month_Name` | `dt.month`, `dt.strftime('%b')` | Seasonality & monthly trends |
| `Quarter` | `dt.to_period('Q')` | Quarterly financial reporting |
| `Day_of_Week` | `dt.day_name()` | Weekend vs. weekday traffic |
| `Age_Group` | Binning (`18-25`, `26-35`, `36-50`, `50+`) | Demographic customer segmentation |
| `Gross_Sales` | `Quantity * Price_per_Unit` | Pre-discount baseline |
| `Discount_Value` | `Gross_Sales * (Discount_Percent / 100)` | Financial cost of promotions |

---

## 4. Step-by-Step Build Roadmap

```
├── [DONE] Step 1: Data Acquisition & Validation (Raw ingestion, schema checks)
├── [NEXT] Step 2: Data Cleaning & Feature Engineering (Date extraction, age bins, gross margins)
├── [PENDING] Step 3: Exploratory Data Analysis & Statistical Modeling (Distribution, correlation, seasonality)
├── [PENDING] Step 4: Core Analytics Engine & KPI Aggregation (Monthly trends, category & cohort analysis)
└── [PENDING] Step 5: Production Streamlit Dashboard (Glassmorphic UI, Plotly charts, reactive filters)
```

### Detailed Phase Breakdown:

#### 🟢 Step 1: Data Ingestion & Schema Audit (Completed)
* Generate & validate 2,000 raw retail transactions.
* Ensure zero missing values, clean IDs, and valid numeric bounds.
* Verified via [`src/run_step1.py`](file:///c:/Users/ADMIN/OneDrive/Documents/Retail%20Sales%20Data%20Exploration%20and%20analysis%20dashboard/src/run_step1.py).

#### 🟡 Step 2: Data Cleaning & Feature Engineering
* Normalize column names to snake_case.
* Parse datetime objects and create calendar features (`year`, `month`, `quarter`, `day_of_week`, `is_weekend`).
* Create demographic age cohorts and discount metrics.
* Persist cleaned output to [`data/processed/cleaned_retail_sales.csv`](file:///c:/Users/ADMIN/OneDrive/Documents/Retail%20Sales%20Data%20Exploration%20and%20analysis%20dashboard/data/processed/cleaned_retail_sales.csv).

#### 🔵 Step 3: Exploratory Data Analysis (EDA)
* Analyze overall revenue growth rates, monthly seasonality, and peaks.
* Unpack category revenue shares and price elasticity.
* Study customer demographic spending power and payment method preferences.
* Document findings in [`notebooks/01_retail_sales_eda.ipynb`](file:///c:/Users/ADMIN/OneDrive/Documents/Retail%20Sales%20Data%20Exploration%20and%20analysis%20dashboard/notebooks/01_retail_sales_eda.ipynb).

#### 🟣 Step 4: Core Analytics Engine
* Implement modular computation functions in [`src/analysis.py`](file:///c:/Users/ADMIN/OneDrive/Documents/Retail%20Sales%20Data%20Exploration%20and%20analysis%20dashboard/src/analysis.py):
  - KPI summary generator (Revenue, Orders, Units, AOV, Avg Rating, Margin).
  - Time-series aggregation (Daily, Monthly, Quarterly).
  - Multi-dimensional cross-tabulations (Category by Region, Gender by Category).

#### 🔴 Step 5: Interactive Web Dashboard
* Modern Streamlit application in [`src/dashboard.py`](file:///c:/Users/ADMIN/OneDrive/Documents/Retail%20Sales%20Data%20Exploration%20and%20analysis%20dashboard/src/dashboard.py).
* Multi-select sidebar filters (Date Range, Region, Category, Payment Method).
* Interactive Plotly charts (Time-series lines, category bar charts, regional sunburst/treemap, age distribution histograms).
* CSV/Excel download button for filtered data views.

---

## 5. KPIs & Mathematical Formulations

$$\text{Total Revenue} = \sum (\text{Total Amount})$$

$$\text{Average Order Value (AOV)} = \frac{\text{Total Revenue}}{\text{Total Number of Orders}}$$

$$\text{Average Units Per Order (UPT)} = \frac{\text{Total Units Sold}}{\text{Total Transactions}}$$

$$\text{Discount Rate Impact} = \frac{\sum \text{Discount Value}}{\sum \text{Gross Sales}} \times 100$$

$$\text{Customer Satisfaction Score (CSAT)} = \frac{\sum \text{Customer Rating}}{\text{Total Ratings Count}}$$

---

## 6. Interactive Dashboard UI/UX Design

```
+---------------------------------------------------------------------------------------------+
|  🛍️ RETAIL SALES EXPLORATION & ANALYSIS DASHBOARD                                           |
|  [ Date Range Filter ] [ Region Filter ] [ Category Filter ] [ Payment Method Filter ]     |
+---------------------------------------------------------------------------------------------+
|  [ 💵 Total Revenue ]   [ 📦 Total Orders ]   [ 🏷️ Units Sold ]   [ 🛒 Avg Order Value ]    |
|       $536,920.40              2,000                 3,560                 $268.46          |
+---------------------------------------------------------------------------------------------+
|  📈 REVENUE & SALES TRENDS (Timeline)         |  📊 CATEGORY PERFORMANCE & REVENUE SHARE    |
|  [ Interactive Plotly Line/Area Chart ]       |  [ Horizontal Stacked Bar / Treemap ]       |
+---------------------------------------------------------------------------------------------+
|  👥 CUSTOMER DEMOGRAPHICS & BEHAVIOR          |  🌍 REGIONAL & STORE PERFORMANCE            |
|  [ Age Group vs Spending by Gender Bar Chart] |  [ Geographic Regional Comparison Chart ]   |
+---------------------------------------------------------------------------------------------+
|  📑 RECENT FILTERED TRANSACTIONS TABLE  |  [ ⬇️ Download Filtered CSV / Excel Dataset ]     |
+---------------------------------------------------------------------------------------------+
```

---

## 7. Technology Stack

* **Language**: Python 3.10+
* **Data Manipulation**: `pandas`, `numpy`
* **Exploratory Notebooks**: `jupyter`, `ipykernel`
* **Data Visualization**: `plotly`, `seaborn`, `matplotlib`
* **Web Dashboard**: `streamlit`
* **File Formats**: CSV, Excel (`openpyxl`), Parquet

---

## 8. Execution Commands & Quick Reference

```bash
# 1. Re-run Step 1 Data Validation
python src/run_step1.py

# 2. Run Step 2 Data Cleaning & Feature Pipeline
python src/data_processing.py

# 3. Launch EDA Notebook
jupyter notebook notebooks/01_retail_sales_eda.ipynb

# 4. Launch Interactive Web Dashboard
streamlit run src/dashboard.py
```
