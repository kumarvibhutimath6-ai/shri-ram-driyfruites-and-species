# 🛍️ Retail Sales Data Exploration & Analysis Dashboard

An end-to-end data analytics system for exploring retail sales trends, customer behavior, and product performance with an interactive web dashboard.

---

## 📁 Project Structure

```plaintext
Retail Sales Data Exploration and analysis dashboard/
├── assets/                          # Static assets (images, logos, styling)
│   └── README.md
├── data/
│   ├── raw/                         # Raw, immutable transactional data
│   │   ├── README.md
│   │   └── retail_sales_dataset.csv # 2,000 retail transactions (2023-2024)
│   └── processed/                   # Cleaned & feature-engineered data
│       ├── README.md
│       └── cleaned_retail_sales.csv # Cleaned dataset with 32 features
├── notebooks/                       # Exploratory Data Analysis
│   └── 01_retail_sales_eda.ipynb    # Comprehensive EDA notebook
├── src/                             # Python Modules
│   ├── __init__.py
│   ├── data_loader.py               # Ingestion & health diagnostics
│   ├── generate_sample_data.py      # Synthetic data generator engine
│   ├── run_step1.py                 # Step 1 quality audit runner
│   ├── data_processing.py           # Cleaning & feature engineering pipeline
│   ├── analysis.py                  # KPI calculations & RFM segmentation
│   ├── dashboard.py                 # Streamlit web dashboard application
│   └── utils.py                     # Number & currency formatting
├── .gitignore                       # Standard exclusions
├── BLUEPRINT.md                     # Architectural design & roadmap
├── requirements.txt                 # Project dependencies
├── main.py                          # Master orchestration CLI runner
└── README.md                        # Documentation & setup guide
```

---

## 🚀 Quick Start Guide

### 1. Run the Entire End-to-End Pipeline
Execute data ingestion, schema validation, cleaning, feature engineering, and KPI computation:

```bash
python main.py
```

### 2. Launch the Interactive Web Dashboard
Run the Streamlit analytics app:

```bash
streamlit run src/dashboard.py
```
*(Or use `python main.py --dashboard`)*

### 3. Open the Exploratory Analysis (EDA) Notebook
```bash
jupyter notebook notebooks/01_retail_sales_eda.ipynb
```

---

## 📊 Key Features & Functionality

1. **Automated Ingestion & Quality Audit (`src/data_loader.py` / `src/run_step1.py`)**:
   - Zero-dependency synthetic generator with realistic product hierarchies, seasonal dates, demographics, and prices.
   - Comprehensive quality checks for null values, duplicates, and data type alignment.

2. **Feature Engineering Pipeline (`src/data_processing.py`)**:
   - Temporal features: `year`, `month`, `quarter`, `day_name`, `is_weekend`.
   - Financial dimensions: `gross_amount`, `discount_amount`, `estimated_cost`, `estimated_profit`, `profit_margin_pct`.
   - Customer cohorts: `age_group` (`18-25`, `26-35`, `36-50`, `51-65`, `65+`).

3. **Core Analytics & RFM Segmentation (`src/analysis.py`)**:
   - Top-level executive metrics (Total Revenue, AOV, Gross Margin %, CSAT rating).
   - Recency, Frequency, Monetary (RFM) customer segmentation (Champions, Loyal, At Risk, Hibernating).
   - Category performance, store ranking, and payment channel cross-tabulations.

4. **Streamlit Web Dashboard (`src/dashboard.py`)**:
   - Multi-select sidebar filtering (Date Range, Categories, Regions, Channels, Demographics).
   - 5 dedicated analytical tabs:
     - 📈 **Sales & Revenue Trends**: Monthly revenue vs profit, MoM growth %, Day-of-week traffic.
     - 🛍️ **Product & Categories**: Revenue share, Treemap hierarchy, Top 10 best-selling items.
     - 👥 **Customer & RFM Intelligence**: Age/Gender spending cohorts, satisfaction rating donut chart, RFM leaderboard.
     - 🌍 **Regional & Channels**: Global geographic breakdown, store ranking, payment channels.
     - 📑 **Data Explorer & Export**: Searchable data table with instant CSV export.
