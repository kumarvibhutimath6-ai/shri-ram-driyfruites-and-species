# Raw Data Directory

Place your original, immutable retail sales data files (e.g., CSV, Excel, JSON) in this directory.
Do not modify files in this directory directly; transform them through cleaning/processing scripts into `data/processed/`.
