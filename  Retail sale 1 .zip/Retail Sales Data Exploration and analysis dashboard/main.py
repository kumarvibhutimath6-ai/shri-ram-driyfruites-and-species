"""
Main Orchestration CLI
Retail Sales Data Exploration & Analysis Dashboard
"""

import sys
import argparse
import subprocess
from pathlib import Path

# Ensure UTF-8 output encoding for Windows terminals
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.append(str(ROOT_DIR))

from src.run_step1 import execute_step1
from src.data_processing import run_processing_pipeline
from src.analysis import compute_executive_kpis, get_category_performance
from src.data_loader import load_processed_data


def run_full_pipeline():
    print("=" * 65)
    print("🚀 RUNNING FULL END-TO-END RETAIL SALES PIPELINE")
    print("=" * 65)

    # 1. Step 1: Ingestion & Validation
    execute_step1()

    print("\n")
    # 2. Step 2: Data Cleaning & Feature Engineering
    run_processing_pipeline()

    print("\n")
    # 3. Step 3 & 4: Executive Analytics Summary
    print("=" * 60)
    print("📊 STEP 3 & 4: EXECUTIVE KPI COMPUTATION")
    print("=" * 60)
    df = load_processed_data("cleaned_retail_sales.csv")
    kpis = compute_executive_kpis(df)
    print(f"• Total Net Revenue     : ${kpis['total_revenue']:,.2f}")
    print(f"• Gross Margin          : {kpis['profit_margin_pct']}% (${kpis['estimated_profit']:,.2f} profit)")
    print(f"• Total Orders / Units  : {kpis['total_orders']:,} orders ({kpis['total_units']:,} units)")
    print(f"• Average Order Value   : ${kpis['average_order_value']:,.2f}")
    print(f"• Customer Satisfaction : ★ {kpis['average_rating']} / 5.0")
    print("=" * 60)
    print("\n🎉 ALL PIPELINE STEPS EXECUTED SUCCESSFULLY!")
    print("To launch the interactive dashboard, run: streamlit run src/dashboard.py")


def launch_dashboard():
    print("🚀 Starting Streamlit Web Dashboard...")
    subprocess.run(["streamlit", "run", "src/dashboard.py"])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Retail Sales Dashboard Pipeline CLI")
    parser.add_argument("--all", action="store_true", help="Run full pipeline (Steps 1-4)")
    parser.add_argument("--step1", action="store_true", help="Run Step 1 (Ingestion & Schema Audit)")
    parser.add_argument("--step2", action="store_true", help="Run Step 2 (Data Cleaning & Features)")
    parser.add_argument("--dashboard", action="store_true", help="Launch Streamlit Dashboard")

    args = parser.parse_args()

    if args.step1:
        execute_step1()
    elif args.step2:
        run_processing_pipeline()
    elif args.dashboard:
        launch_dashboard()
    else:
        run_full_pipeline()
