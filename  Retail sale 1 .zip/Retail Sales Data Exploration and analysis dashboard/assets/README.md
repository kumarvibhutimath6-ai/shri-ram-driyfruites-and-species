# Assets Directory

Store static assets used in dashboards, reports, and documentation here:
- `images/`: Screenshots, logos, generated charts, and diagrams
- `css/` or `styles/`: Custom styling sheets for dashboards or reports
============================================================
EXECUTING STEP 1: DATA INGESTION & QUALITY AUDIT
============================================================
[OK] Found raw dataset at: retail_sales_dataset.csv

--- DATASET HEALTH & QUALITY REPORT ---
* Total Rows Recorded : 2,000
* Total Columns       : 15
* Duplicate Rows      : 0
* Missing Values      : 0 (100% complete dataset)

--- SCHEMA & COLUMN TYPES ---
  - Transaction_ID       | Type: str        | Sample: TXN-101076
  - Date                 | Type: str        | Sample: 2023-01-01
  - Customer_ID          | Type: str        | Sample: CUST-1154
  - Gender               | Type: str        | Sample: Male
  - Age                  | Type: int64      | Sample: 63
  - Product_Category     | Type: str        | Sample: Beauty & Personal Care
  - Product_Name         | Type: str        | Sample: Lipstick
  - Quantity             | Type: int64      | Sample: 3
  - Price_per_Unit       | Type: float64    | Sample: $19.18
  - Discount_Percent     | Type: int64      | Sample: 10%
  - Total_Amount         | Type: float64    | Sample: $51.79
  - Payment_Method       | Type: str        | Sample: Digital Wallet
  - Region               | Type: str        | Sample: North America
  - Store_ID             | Type: str        | Sample: STR-114
  - Customer_Rating      | Type: int64      | Sample: 3

--- CATEGORY BREAKDOWN ---
  * Clothing                 : 609 orders (30.4%)
  * Electronics              : 513 orders (25.7%)
  * Beauty & Personal Care   : 377 orders (18.9%)
  * Home & Kitchen           : 298 orders (14.9%)
  * Books & Stationery       : 203 orders (10.2%)
============================================================

python src/run_step1.py


